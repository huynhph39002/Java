package com.example.btvnbuoi8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Btvnbuoi8ApplicationTests {

    @Test
    void contextLoads() {
    }

}
