package com.example.btvnbuoi8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Btvnbuoi8Application {

    public static void main(String[] args) {
        SpringApplication.run(Btvnbuoi8Application.class, args);
    }

}
