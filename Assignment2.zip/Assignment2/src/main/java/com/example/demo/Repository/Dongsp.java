package com.example.demo.Repository;

import com.example.demo.Enty.DongSanPhamEnty;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Dongsp extends JpaRepository<DongSanPhamEnty ,Integer> {

    DongSanPhamEnty findAllById(Integer id);
}
