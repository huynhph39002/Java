package com.example.demo.Repository;

import com.example.demo.Enty.MauSacEnty;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MauSacRepo extends JpaRepository<MauSacEnty ,Integer> {
    MauSacEnty findAllById(Integer id);
}
