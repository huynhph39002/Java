package com.example.demo.Controller;

import com.example.demo.Enty.ChiTietSanPhamEnty;
import com.example.demo.Enty.ChucVuEnty;
import com.example.demo.Enty.NhanVienEnTy;
import com.example.demo.Repository.ChiTietSanPhamrepo;
import com.example.demo.Repository.Dongsp;
import com.example.demo.Repository.MauSacRepo;
import com.example.demo.Repository.NSXRepo;
import com.example.demo.Repository.SanPhamrepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class ChiTietSanPham {
    @Autowired
    ChiTietSanPhamrepo ctsprepo;
    @Autowired
    SanPhamrepo sprepo;
    @Autowired
    NSXRepo nsxrepo;
    @Autowired
    Dongsp dsprepo;
    @Autowired
    MauSacRepo msrepo;


    @GetMapping("ChiTietSanPham/hienthi")
    public String hienthi(Model model) {
        model.addAttribute("list", ctsprepo.findAll());
        return "ChiTietSanPham/ChiTietSanPham";
    }

    @GetMapping("ChiTietSanPham/add")
    public String add1(Model model) {
        model.addAttribute("listsp", sprepo.findAll());
        model.addAttribute("listnsx", nsxrepo.findAll());
        model.addAttribute("listms", msrepo.findAll());
        model.addAttribute("listdsp", dsprepo.findAll());
        return "/ChiTietSanPham/Add";
    }

    @PostMapping("ChiTietSanPham2/add")
    public String add2(ChiTietSanPhamEnty cv) {
        ctsprepo.save(cv);
        return "redirect:/ChiTietSanPham/hienthi";

    }

    //    @GetMapping("ChiTietSanPham/delete/{ma}")
//    public String xoa(@PathVariable("ma") Integer ma , Model model){
//        List<NhanVienEnTy> xoa=nvrepo.checkxoacv(ma);
//        if(xoa.size()!=0){
//            model.addAttribute("loi","khong the xoa");
//            return "/ChucVu/ChucVu";
//        }
//        repo.deleteById(ma);
//        return "redirect:/ChiTietSanPham/hienthi";
//    }
    @GetMapping("ChiTietSanPham/update/{ma}")
    public String update(@PathVariable("ma") Integer ma, Model model) {
        model.addAttribute("list1", ctsprepo.findAllById(ma));
        model.addAttribute("listsp", sprepo.findAll());
        model.addAttribute("listnsx", nsxrepo.findAll());
        model.addAttribute("listms", msrepo.findAll());
        model.addAttribute("listdsp", dsprepo.findAll());
        return "ChiTietSanPham/Update";

    }

    @PostMapping("ChiTietSanPham2/updatee")
    public String update(ChiTietSanPhamEnty ct) {
        ctsprepo.save(ct);
        return "redirect:/ChiTietSanPham/hienthi";
    }


}
