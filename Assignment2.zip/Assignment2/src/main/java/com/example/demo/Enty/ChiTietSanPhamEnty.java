package com.example.demo.Enty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "ChiTietSP")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ChiTietSanPhamEnty {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private Integer id;


    @ManyToOne
    @JoinColumn(name = "IdSP" ,referencedColumnName = "id")
    private  SanPhamEnty sp;

    @ManyToOne
    @JoinColumn(name = "IdNsx" ,referencedColumnName = "id")
    private  NhaSanXuatEnty nsx;

    @ManyToOne
    @JoinColumn(name = "IdMauSac" ,referencedColumnName = "id")
    private  MauSacEnty mss;

    @ManyToOne
    @JoinColumn(name = "IdDongSP" ,referencedColumnName = "id")
    private  DongSanPhamEnty dsp;

    @Column(name = "NamBH")
    private Integer nambh;

    @Column(name = "MoTa")
    private String mota;

    @Column(name = "SoLuongTon")
    private Integer slt;


    @Column(name = "GiaNhap")
    private Double gianhap;

    @Column(name = "GiaBan")
    private Double giaban;



}
