package com.example.demo.Controller;

import com.example.demo.Services.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller

public class CartController {
    @Autowired
    private CartService cartService;

    @GetMapping("/cart/{id}")
    public String viewCart(@PathVariable Long id, Model model) {
        model.addAttribute("cart", cartService.getCart(id));
        return "cart";
    }

    @PostMapping("/cart/add")
    public String addToCart(@RequestParam Long cartId, @RequestParam Long productId, @RequestParam int quantity) {
        cartService.addItemToCart(cartId, productId, quantity);
        return "redirect:/cart/" + cartId;
    }
}