package com.example.demo.Controller;

import com.example.demo.Enty.ChucVuEnty;
import com.example.demo.Enty.CuaHangEnty;
import com.example.demo.Enty.NhanVienEnTy;
import com.example.demo.Repository.ChucVuRepo;
import com.example.demo.Repository.CuaHangRepo;
import com.example.demo.Repository.NhanVienRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class ChucVu {
    @Autowired
    ChucVuRepo repo;
    @Autowired
    NhanVienRepo nvrepo;
    @GetMapping("ChucVu/hienthi")
    public String hienthi(Model model){
        model.addAttribute("list",repo.findAll());
        return "ChucVu/ChucVu";
    }
    @PostMapping("ChucVu/add")
    public String add(ChucVuEnty cv) {
        repo.save(cv);
        return "redirect:/ChucVu/hienthi";

    }
    @GetMapping("ChucVu/delete/{ma}")
    public String xoa(@PathVariable("ma") Integer ma , Model model){
        List<NhanVienEnTy> xoa=nvrepo.checkxoacv(ma);
        if(xoa.size()!=0){
            model.addAttribute("loi","khong the xoa");
            return "/ChucVu/ChucVu";
        }
        repo.deleteById(ma);
        return "redirect:/ChucVu/hienthi";
    }
    @GetMapping("ChucVu/update/{ma}")
    public String update(@PathVariable("ma") Integer ma,Model model){
        model.addAttribute("list1",repo.findAllById(ma));
        return "ChucVu/Update";

    }

    @PostMapping("ChucVu/updatee")
    public String update(ChucVuEnty cv) {
        repo.save(cv);
        return "redirect:/ChucVu/hienthi";
    }
}
