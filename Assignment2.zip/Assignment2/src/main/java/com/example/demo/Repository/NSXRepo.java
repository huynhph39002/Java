package com.example.demo.Repository;

import com.example.demo.Enty.NhaSanXuatEnty;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NSXRepo extends JpaRepository<NhaSanXuatEnty , Integer> {

    NhaSanXuatEnty findAllById(Integer id);
}
