package com.example.demo.Repository;

import com.example.demo.Enty.HoaDonEnty;
import com.example.demo.Enty.NhanVienEnTy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface NhanVienRepo extends JpaRepository<NhanVienEnTy ,Integer> {
    NhanVienEnTy  findAllById(Integer id);

    @Query("select c from NhanVienEnTy c where c.ch.id=:id ")
    List<NhanVienEnTy> checkxoakh(@Param("id") Integer id);

    @Query("select c from NhanVienEnTy c where c.cv.id=:id ")
    List<NhanVienEnTy> checkxoacv(@Param("id") Integer id);
}
