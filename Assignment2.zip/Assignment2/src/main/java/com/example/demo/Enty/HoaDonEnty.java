package com.example.demo.Enty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Entity
@Table(name = "HoaDon")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HoaDonEnty {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "IdKH",referencedColumnName = "Id")
    private KhachHangEnTy idkh;

    @ManyToOne
    @JoinColumn(name = "IdNV" ,referencedColumnName = "Id")
    private NhanVienEnTy idnv;




    @Column(name = "Ma")
    private String ma;

    @Column(name = "NgayTao")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date ngaytao;

    @Column(name = "NgayThanhToan")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date ngaythanhtoan;

    @Column(name = "NgayShip")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date ngayship;

    @Column(name = "NgayNhan")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date ngaynhan;


    @Column(name = "TinhTrang")
    private Integer tinhtrang;

    @Column(name = "TenNguoiNhan")
    private String tennguoinhan;

    @Column(name = "DiaChi")
    private String diachi;

    @Column(name = "Sdt")
    private String sdt;





}
