package com.example.demo.Repository;

import com.example.demo.Enty.SanPhamEnty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SanPhamrepo  extends JpaRepository<SanPhamEnty,Integer> {
    SanPhamEnty findAllById(Integer id);




}
