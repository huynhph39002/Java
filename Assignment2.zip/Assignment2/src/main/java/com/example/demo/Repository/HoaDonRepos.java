package com.example.demo.Repository;

import com.example.demo.Enty.HoaDonEnty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HoaDonRepos extends JpaRepository<HoaDonEnty,Integer> {
}
