package com.example.demo.Repository;

import com.example.demo.Enty.ChiTietSanPhamEnty;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChiTietSanPhamrepo  extends JpaRepository<ChiTietSanPhamEnty ,Integer> {

    ChiTietSanPhamEnty findAllById(Integer id);
}
