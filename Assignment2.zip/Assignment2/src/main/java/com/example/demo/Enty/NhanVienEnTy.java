package com.example.demo.Enty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Entity
@Table(name = "NhanVien")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
public class NhanVienEnTy {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private Integer id;

    @Column(name = "Ma")
    private String ma;

    @Column(name = "Ten")
    private String ten;
    @Column(name = "TenDem")
    private String tendem;
    @Column(name = "Ho")
    private String ho;
    @Column(name = "GioiTinh")
    private String gioitinh;

    @Column(name = "NgaySinh")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date ngaysinh;
    @Column(name = "DiaChi")
    private String diachi;

    @Column(name = "Sdt")
    private String sdt;

    @ManyToOne
    @JoinColumn(name = "IdCH" ,referencedColumnName = "id")
    private  CuaHangEnty ch;


    @ManyToOne
    @JoinColumn(name = "IdCV" ,referencedColumnName = "id")
    private  ChucVuEnty cv;

    @Column(name = "TrangThai")
    private Integer trangthai;
}
