package com.example.demo.Repository;

import com.example.demo.Enty.ChucVuEnty;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChucVuRepo extends JpaRepository<ChucVuEnty ,Integer> {
    ChucVuEnty findAllById(Integer id);
}
