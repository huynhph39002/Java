package com.example.demo.Controller;

import com.example.demo.Enty.NhaSanXuatEnty;
import com.example.demo.Enty.SanPhamEnty;
import com.example.demo.Repository.NSXRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class Nhasx {
    @Autowired
    NSXRepo repo;
    @GetMapping("NSX/hienthi")
    public String hienthi(Model model){
        model.addAttribute("list",repo.findAll());
        return "NSX/NSX";
    }
    @PostMapping("NSX/add")
    public String add(NhaSanXuatEnty sp){
        repo.save(sp);
        return "redirect:/NSX/hienthi";
    }
    @GetMapping("/NSX/remove/{ma}")
    public String remove(@PathVariable("ma") Integer ma){
        repo.deleteById(ma);
        return "redirect:/NSX/hienthi";
    }

    @GetMapping("NSX/update/{ma}")
    public String update(@PathVariable("ma") Integer ma, Model model){
        model.addAttribute("list1",repo.findAllById(ma));
        return "NSX/Update";
    }
    @PostMapping("NSX/update")
    public String updatet(NhaSanXuatEnty sp){
        repo.save(sp);
        return "redirect:/NSX/hienthi";
    }
}
