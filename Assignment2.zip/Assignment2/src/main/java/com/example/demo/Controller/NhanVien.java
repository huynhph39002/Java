package com.example.demo.Controller;

import com.example.demo.Enty.HoaDonEnty;
import com.example.demo.Enty.NhanVienEnTy;
import com.example.demo.Repository.DangNhaprepo;
import com.example.demo.Repository.HoaDonRepo;
import com.example.demo.Repository.NhanVienRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class NhanVien {

    private final NhanVienRepo repo;
    private final HoaDonRepo hdRepo;

    @GetMapping("nhanvien")
    public String nhanvienhienthi(Model model) {
        model.addAttribute("list", repo.findAll());
        return "/NhanVien/NhanVien";
    }

    @PostMapping("add")
    public String add2(NhanVienEnTy nv) {
        repo.save(nv);
        return "redirect:/nhanvien";
    }

    @GetMapping("/delete/{ma}")
    public String remove(@PathVariable("ma") Integer ma ,Model model) {
        List<HoaDonEnty>  xoa=hdRepo.checkxoa(ma);
        if(xoa.size()!=0){
            model.addAttribute("loi","khong the xoa");
            return "/NhanVien/NhanVien";
        }
        repo.deleteById(ma);
        return "redirect:/nhanvien";
    }

    @GetMapping("/update/{ma}")
    public String update(@PathVariable("ma") Integer ma, Model model) {
        model.addAttribute("list1", repo.findAllById(ma));
        return "/NhanVien/Update";
    }

    @PostMapping("update")
    public String update2(NhanVienEnTy nv) {
        repo.save(nv);
        return "redirect:/nhanvien";
    }
}
