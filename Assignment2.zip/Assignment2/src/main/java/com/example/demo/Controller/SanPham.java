package com.example.demo.Controller;

import com.example.demo.Enty.SanPhamEnty;
import com.example.demo.Repository.SanPhamrepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SanPham {

    @Autowired
    SanPhamrepo repo;
    @GetMapping("SanPham/hienthi")
    public String hienthi(Model model){
        model.addAttribute("list",repo.findAll());
        return "/SanPham/SanPham";
    }
    @PostMapping("SanPham/add")
    public String add(SanPhamEnty sp){
        repo.save(sp);
        return "redirect:/SanPham/hienthi";
    }
    @GetMapping("/SanPham/remove/{ma}")
    public String remove(@PathVariable("ma") Integer ma){
        repo.deleteById(ma);
        return "redirect:/SanPham/hienthi";
    }

    @GetMapping("SanPham/update/{ma}")
    public String update(@PathVariable("ma") Integer ma, Model model){
        model.addAttribute("list1",repo.findAllById(ma));
        return "SanPham/Update";
    }
    @PostMapping("SanPham/update")
    public String updatet(SanPhamEnty sp){
        repo.save(sp);
        return "redirect:/SanPham/hienthi";
    }
}
