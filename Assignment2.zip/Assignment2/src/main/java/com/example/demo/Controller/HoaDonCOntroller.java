package com.example.demo.Controller;

import com.example.demo.Repository.HoaDonRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HoaDonCOntroller {
    @Autowired
    private HoaDonRepos hdRepos;
    @GetMapping("/hoa-don/hienthi")
    public String show(Model model){
        model.addAttribute("list",hdRepos.findAll());
        return "HoaDon/HoaDon";
    }
}
