package com.example.demo.Repository;

import com.example.demo.Enty.KhachHangEnTy;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KhachHangrepo extends JpaRepository<KhachHangEnTy ,Integer > {
    KhachHangEnTy findAllById(Integer id);



}
