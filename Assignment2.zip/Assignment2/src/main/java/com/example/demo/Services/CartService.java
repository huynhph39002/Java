package com.example.demo.Services;

import com.example.demo.Enty.Cart;
import com.example.demo.Enty.CartItem;
import com.example.demo.Enty.Product;
import com.example.demo.Repository.CartRepository;
import com.example.demo.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class CartService {
    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;

    public Cart getCart(Long id) {
        return cartRepository.findById(Math.toIntExact(id)).orElse(new Cart());
    }

    public void addItemToCart(Long cartId, Long productId, int quantity) {
        Cart cart = getCart(cartId);
        Optional<Product> product = productRepository.findById(Math.toIntExact(productId));

        if (product.isPresent()) {
            CartItem cartItem = new CartItem();
            cartItem.setProduct(product.get());
            cartItem.setQuantity(quantity);
            cart.getItems().add(cartItem);
            cartRepository.save(cart);
        }
    }
}
