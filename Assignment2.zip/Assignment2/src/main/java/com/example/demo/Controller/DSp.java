package com.example.demo.Controller;

import com.example.demo.Enty.DongSanPhamEnty;
import com.example.demo.Enty.NhaSanXuatEnty;
import com.example.demo.Repository.Dongsp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class DSp {
    @Autowired
    private Dongsp repo;
    @GetMapping("DSP/hienthi")
    public String hienthi(Model model){
        model.addAttribute("list",repo.findAll());
        return "DSP/DSP";
    }
    @PostMapping("DSP/add")
    public String add(DongSanPhamEnty sp){
        repo.save(sp);
        return "redirect:/DSP/hienthi";
    }
    @GetMapping("/DSP/remove/{ma}")
    public String remove(@PathVariable("ma") Integer ma){
        repo.deleteById(ma);
        return "redirect:/DSP/hienthi";
    }

    @GetMapping("DSP/update/{ma}")
    public String update(@PathVariable("ma") Integer ma, Model model){
        model.addAttribute("list1",repo.findAllById(ma));
        return "DSP/Update";
    }
    @PostMapping("DSP/update")
    public String updatet(DongSanPhamEnty sp){
        repo.save(sp);
        return "redirect:/DSP/hienthi";
    }
}
