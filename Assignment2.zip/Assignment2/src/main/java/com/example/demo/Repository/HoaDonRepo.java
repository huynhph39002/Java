package com.example.demo.Repository;

import com.example.demo.Enty.HoaDonEnty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HoaDonRepo  extends JpaRepository<HoaDonEnty , Integer> {
    @Query("select c from HoaDonEnty c where c.idnv.id=:id ")
    List<HoaDonEnty> checkxoa(@Param("id") Integer id);


    @Query("select c from HoaDonEnty c where c.idkh.id=:id ")
    List<HoaDonEnty> checkxoakh(@Param("id") Integer id);





}
