package com.example.demo.Controller;

import com.example.demo.Enty.DongSanPhamEnty;
import com.example.demo.Enty.MauSacEnty;
import com.example.demo.Repository.MauSacRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MauSac {
    @Autowired
    MauSacRepo repo;
    @GetMapping("/MauSac/hienthi")
    public String hienthi(Model model){
        model.addAttribute("list",repo.findAll());
        return "MauSac/MauSac";
    }
    @PostMapping("MauSac/add")
    public String add(MauSacEnty sp){
        repo.save(sp);
        return "redirect:/MauSac/hienthi";
    }
    @GetMapping("/MauSac/remove/{ma}")
    public String remove(@PathVariable("ma") Integer ma){
        repo.deleteById(ma);
        return "redirect:/MauSac/hienthi";
    }

    @GetMapping("MauSac/update/{ma}")
    public String update(@PathVariable("ma") Integer ma, Model model){
        model.addAttribute("list1",repo.findAllById(ma));
        return "MauSac/Update";
    }
    @PostMapping("MauSac/update")
    public String updatet(MauSacEnty sp){
        repo.save(sp);
        return "redirect:/MauSac/hienthi";
    }
}
