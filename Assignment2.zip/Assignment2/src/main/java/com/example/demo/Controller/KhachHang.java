package com.example.demo.Controller;

import com.example.demo.Enty.HoaDonEnty;
import com.example.demo.Enty.KhachHangEnTy;
import com.example.demo.Repository.HoaDonRepo;
import com.example.demo.Repository.KhachHangrepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class KhachHang {
    @Autowired
    KhachHangrepo repo;
    @Autowired
    HoaDonRepo hdrepo;

    @GetMapping("/khachhang")
    public String khachhang(Model model){
        model.addAttribute("list", repo.findAll());
        return "/KhachHang/KhachHang";
    }

    @GetMapping("/add1")
    public String add(){
        return "/KhachHang/Add";
    }

    @PostMapping("/khachhang/add")
    public String add2(KhachHangEnTy kh) {
        repo.save(kh);
        return "redirect:/khachhang";
    }

    @GetMapping("/khachhang/delete/{ma}")
    public String remove(@PathVariable("ma") Integer ma, Model model) {
        List<HoaDonEnty> xoa = hdrepo.checkxoakh(ma);
        if (xoa.size() != 0) {
            model.addAttribute("loi", "khong the xoa");
            return "/KhachHang/KhachHang";
        }
        repo.deleteById(ma);
        return "redirect:/khachhang";
    }

    @GetMapping("/khachhang/update/{ma}")
    public String update(@PathVariable("ma") Integer ma, Model model) {
        model.addAttribute("list1", repo.findAllById(ma));
        return "/KhachHang/Update";
    }

    @PostMapping("/khachhangg/update")
    public String update2(KhachHangEnTy kh) {
        repo.save(kh);
        return "redirect:/khachhang";
    }
}
